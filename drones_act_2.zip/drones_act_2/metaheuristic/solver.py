# Solver metaheuristico (simulated annealing). Va cambiando la ruta con swaps.
# A veces acepta una solucion peor para salir de un optimo local.

"""
Metaheurística: Simulated Annealing (SA)
- Trabaja sobre permutaciones de nodos (hub fijo)
- Vecindario: swap de dos posiciones o 2-opt
- Función objetivo escalarizada para explorar Pareto:
    cost = wD*dist + wR*risk + wC*recharges_penalty
  donde recharges_penalty = recargas * scale

Para recoger variedad, se lanzan varias ejecuciones con distintos pesos.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple
import random
import math

from common.instance import Instance
from common.route import evaluate_route
from common.pareto import pareto_prune

Obj = Tuple[float, float, int]

@dataclass
class MetaSolution:
    obj: Obj
    route: List[int]

def _random_route(inst: Instance, rng: random.Random) -> List[int]:
    hub = inst.hub
    nodes = [i for i in range(inst.n) if i != hub]
    rng.shuffle(nodes)
    return [hub] + nodes + [hub]

def _neighbor(route: List[int], rng: random.Random) -> List[int]:
    # swap dos posiciones internas
    r = route[:]
    i = rng.randint(1, len(r)-3)
    j = rng.randint(1, len(r)-3)
    if i == j:
        j = (j % (len(r)-3)) + 1
    r[i], r[j] = r[j], r[i]
    return r

def solve_one(inst: Instance, wD: float, wR: float, wC: float, iters: int, rng: random.Random) -> List[Tuple[Obj, List[int]]]:
    T0 = 1.0
    Tmin = 1e-3
    alpha = (Tmin / T0) ** (1.0 / max(1, iters-1))

    cur = _random_route(inst, rng)
    cur_ev = evaluate_route(inst, cur)
    # Si sale infeasible, reintentar unas veces
    tries = 0
    while not cur_ev.ok and tries < 200:
        cur = _random_route(inst, rng)
        cur_ev = evaluate_route(inst, cur)
        tries += 1
    if not cur_ev.ok:
        return []

    # Escala para recargas: las ponemos "al mismo orden" que dist/risk
    scale = (cur_ev.obj[0] + cur_ev.obj[1]) / 10.0 + 1.0

    def cost(obj: Obj) -> float:
        return wD * obj[0] + wR * obj[1] + wC * (obj[2] * scale)

    best_set: List[Tuple[Obj, List[int]]] = [(cur_ev.obj, cur_ev.route)]
    cur_cost = cost(cur_ev.obj)

    T = T0
    for _ in range(iters):
        cand = _neighbor(cur, rng)
        ev = evaluate_route(inst, cand)
        if not ev.ok:
            # penalizamos infeasible: sólo aceptamos con prob muy baja
            T *= alpha
            continue
        c = cost(ev.obj)
        delta = c - cur_cost
        if delta <= 0 or rng.random() < math.exp(-delta / max(1e-9, T)):
            cur, cur_ev, cur_cost = cand, ev, c
            best_set = pareto_prune(best_set + [(cur_ev.obj, cur_ev.route)])
        T *= alpha

    return best_set

def solve(inst: Instance, runs: int = 12, iters: int = 2500) -> List[MetaSolution]:
    rng = random.Random(123)
    pareto: List[Tuple[Obj, List[int]]] = []
    weight_sets = [
        (1.0, 0.0, 0.3),
        (0.0, 1.0, 0.3),
        (0.5, 0.5, 0.3),
        (0.7, 0.3, 0.3),
        (0.3, 0.7, 0.3),
        (0.5, 0.5, 1.0),
    ]
    for k in range(runs):
        wD, wR, wC = weight_sets[k % len(weight_sets)]
        sols = solve_one(inst, wD, wR, wC, iters=iters, rng=rng)
        pareto = pareto_prune(pareto + sols)
    return [MetaSolution(obj=o, route=r) for o, r in pareto]