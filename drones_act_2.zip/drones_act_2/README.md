# Actividad 2 — Planificación multiobjetivo de rutas de drones

Este proyecto implementa **tres enfoques** para planificar una ruta tipo **circuito Hamiltoniano** (hub → todos los destinos → hub) minimizando simultáneamente:

- **Distancia total**
- **Riesgo total** (más alto cuanto más cerca se vuela de zonas no-fly)
- **Número de recargas** (recharges) necesarias para completar el circuito

Además, **todas las aristas** (trayectorias rectas entre nodos) deben **evitar intersecciones** con polígonos **no-fly** usando tests geométricos de intersección de segmentos.

## Estructura

- `exact_bb/` → backtracking / branch-and-bound (más “exacto” para N pequeños, con `--time_limit`).
- `geo_heuristic/` → heurística geométrica (greedy + 2-opt).
- `metaheuristic/` → simulated annealing (SA) multiarranque.
- `common/` → carga de instancias, evaluación de rutas, Pareto, geometría y plotting.
- `datasets/` → instancias `.json` (N=10,15,20,25).
- `scripts/` → generación de instancias y experimentos.
- `results/` → salidas y gráficas.

## Requisitos

- Python 3.10+ recomendado
- `matplotlib`

Instalación rápida:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Ejecutar un algoritmo en una instancia

Con Makefile:

```bash
make ejecutar ALG=geo INSTANCE=datasets/inst_10.json
make ejecutar ALG=meta INSTANCE=datasets/inst_15.json
make ejecutar ALG=exact INSTANCE=datasets/inst_10.json
```

O directamente:

```bash
python3 main.py --alg geo --instance datasets/inst_10.json
python3 main.py --alg meta --instance datasets/inst_20.json --runs 12 --iters 2500
python3 main.py --alg exact --instance datasets/inst_10.json --time_limit 3.0
```

Para guardar soluciones:

```bash
python3 main.py --alg geo --instance datasets/inst_10.json --out results/geo_inst10_solutions.json
```

## Experimentos

Ejecuta 5 réplicas por instancia y algoritmo, y genera gráficas:

```bash
make experimento
```

Se guardan:
- `results/metricas.csv`
- `results/time_vs_n.png`
- `results/hypervolume.png`
- `results/diversity.png`
- `results/pareto_inst_25.png` (ejemplo de dispersión)

## Formato de instancia JSON

Mira `datasets/inst_10.json` como plantilla. Los campos importantes son:
- `nodes`: coordenadas (x,y) y tipo
- `recharge_stations`: ids donde se puede recargar
- `battery_capacity`: capacidad (en las mismas unidades que el consumo)
- `polygons`: lista de polígonos no-fly

## Nota sobre “recargas”

En esta implementación, el número de recargas para una ruta se calcula con una **política greedy**:
> “recargo solo si no me alcanza la batería para la siguiente arista, y solo si estoy en una estación”.

Esto permite comparar rutas sin añadir una variable de decisión extra (parar o no parar).

---
Autor: (tu nombre)


> Nota: también existen aliases en inglés (`make run`, `make experiment`, `make gen`) por compatibilidad, pero en la entrega uso los nombres en castellano.
