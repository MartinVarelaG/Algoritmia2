from __future__ import annotations
import argparse, json

# Main del proyecto. Aqui solo parseo argumentos y llamo al solver que toque.
# No hay mucha magia, lo importante esta en exact_bb/ geo_heuristic/ y metaheuristic/ .

from common.instance import load_instance

def main():
    ap = argparse.ArgumentParser(description="Planificación multiobjetivo de rutas de drones (Actividad 2)")
    ap.add_argument("--alg", required=True, choices=["exact", "geo", "meta"], help="Algoritmo a ejecutar")
    ap.add_argument("--instance", required=True, help="Ruta al archivo .json de instancia")
    ap.add_argument("--out", default="", help="Guardar soluciones en JSON (ruta)")
    ap.add_argument("--time_limit", type=float, default=3.0, help="Sólo exact: límite de tiempo (s)")
    ap.add_argument("--seeds", type=int, default=8, help="Sólo geo: número de reinicios/semillas por alpha")
    ap.add_argument("--runs", type=int, default=12, help="Sólo meta: número de ejecuciones SA")
    ap.add_argument("--iters", type=int, default=2500, help="Sólo meta: iteraciones SA por ejecución")
    args = ap.parse_args()

    inst = load_instance(args.instance)

    if args.alg == "exact":
        from exact_bb.solver import solve
        sols = solve(inst, time_limit=args.time_limit)
    elif args.alg == "geo":
        from geo_heuristic.solver import solve
        sols = solve(inst, seeds=args.seeds)
    else:
        from metaheuristic.solver import solve
        sols = solve(inst, runs=args.runs, iters=args.iters)

    if not sols:
        print("No se encontró ninguna solución factible.")
        return

    # sols pueden ser dataclasses con atributos obj/route
    sols_sorted = sorted(sols, key=lambda s: (s.obj[2], s.obj[0], s.obj[1]))
    print(f"Instancia: {inst.name}  N={inst.n}  Alg={args.alg}")
    for s in sols_sorted[:20]:
        print(f"obj={s.obj}  route={s.route}")

    if args.out:
        payload = [{"obj": list(s.obj), "route": s.route} for s in sols_sorted]
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)
        print(f"Guardado: {args.out}")

if __name__ == "__main__":
    main()