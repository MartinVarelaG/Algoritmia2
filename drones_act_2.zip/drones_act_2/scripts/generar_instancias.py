from __future__ import annotations

# Generador de instancias para la actvidad. Hace unos puntos al rededor del hub y mete poligonos no-fly.
# No es super realista, pero sirve para probar los algoritmos y que no sea todo random sin sentido.
import sys
from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))

import json, random, math
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / "datasets"

def square(cx, cy, side):
    s = side/2
    return [(cx-s, cy-s), (cx+s, cy-s), (cx+s, cy+s), (cx-s, cy+s)]

def make_instance(n: int, seed: int) -> dict:
    rng = random.Random(seed)

    # Polígonos no-fly: 1 "central" desplazado + 2 esquinas (y uno extra si n>=20)
    polys = [
        {"id": 0, "points": [[x, y] for (x, y) in square(50, 65, 14)]},
        {"id": 1, "points": [[x, y] for (x, y) in square(10, 90, 10)]},
        {"id": 2, "points": [[x, y] for (x, y) in square(90, 10, 10)]},
    ]
    if n >= 20:
        polys.append({"id": 3, "points": [[x, y] for (x, y) in square(90, 90, 10)]})

    # Hub
    nodes = [{"id": 0, "x": 50.0, "y": 50.0, "type": "hub"}]

    # Nodos en un anillo alrededor del centro
    R = 32.0 if n <= 15 else 36.0
    for i in range(1, n):
        ang = 2 * math.pi * (i-1) / (n-1)
        jitter = rng.uniform(-1.5, 1.5)
        r = R + jitter
        x = 50.0 + r * math.cos(ang)
        y = 50.0 + r * math.sin(ang)
        nodes.append({"id": i, "x": round(x, 3), "y": round(y, 3), "type": "delivery"})

    # Capacidad batería un poco mayor cuando n crece para garantizar factibilidad.
    battery_capacity = 160.0 if n <= 15 else 200.0

    # Estaciones de recarga: hub + una selección que garantice cobertura
    station_ids = {0}
    # Garantía: cada 5 nodos (en ids) es estación => la ruta en orden id es factible con la batería elegida.
    for i in range(1, n):
        if i % 5 == 0:
            station_ids.add(i)

    # Completar hasta ~55% con aleatorio (para dar variedad)
    target = max(6, int(0.55 * n))
    pool = [i for i in range(1, n) if i not in station_ids]
    rng.shuffle(pool)
    for sid in pool:
        if len(station_ids) >= target:
            break
        station_ids.add(sid)

    # marcar nodos station
    for nd in nodes:
        if nd["id"] in station_ids and nd["id"] != 0:
            nd["type"] = "station"

    return {
        "name": f"inst_{n}",
        "hub": 0,
        "nodes": nodes,
        "recharge_stations": sorted(list(station_ids)),
        "battery_capacity": battery_capacity,
        "polygons": polys,
        "risk_beta": 3.0
    }

def main():
    OUT.mkdir(exist_ok=True)
    for n, seed in [(10, 10), (15, 15), (20, 20), (25, 25)]:
        inst = make_instance(n, seed)
        path = OUT / f"inst_{n}.json"
        with open(path, "w", encoding="utf-8") as f:
            json.dump(inst, f, indent=2)
        print("Escribi", path)

if __name__ == "__main__":
    main()