from __future__ import annotations

# Script para hacer el experimento de la actvidad.
# La idea es simple: para cada instancia y cada algoritmo lo corro 5 veces,
# y luego saco el tiempo medio y otras cosillas (memoria, pareto, etc).
# (perdon por las faltas, soy un poco novato xD)

import sys
from pathlib import Path as _Path
sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))

import csv, time, tracemalloc
from pathlib import Path
from statistics import mean

from common.instance import load_instance
from common.pareto import hypervolume_2d, diversity_nn
from common.plotting import plot_time_vs_n, plot_bar, plot_pareto

BASE = Path(__file__).resolve().parents[1]
DATA = BASE / "datasets"
OUT = BASE / "results"
OUT.mkdir(exist_ok=True)

# Parametros pensados para que vaya rapido pero cumpla lo de 5 repeticiones.
ALGOS = [
    ("exact", {"time_limit": 0.5}),   # branch and bound con limite de tiempo
    ("geo",   {"seeds": 2}),          # heuristica rapida (varios seeds)
    ("meta",  {"runs": 4, "iters": 800}),  # simulated annealing (multi-arranque)
]

def ejecutar_solver(inst, alg: str, params: dict):
    """Llama al solver segun el nombre del algoritmo."""
    if alg == "exact":
        from exact_bb.solver import solve
        return solve(inst, time_limit=params.get("time_limit", 0.5))
    if alg == "geo":
        from geo_heuristic.solver import solve
        return solve(inst, seeds=params.get("seeds", 2))
    from metaheuristic.solver import solve
    return solve(inst, runs=params.get("runs", 4), iters=params.get("iters", 800))

def medir_una_vez(inst, alg: str, params: dict):
    """Mide tiempo y memoria pico de una ejecucion."""
    tracemalloc.start()
    t0 = time.perf_counter()
    sols = ejecutar_solver(inst, alg, params)
    t1 = time.perf_counter()
    _, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()
    return (t1 - t0), peak, sols

def main():
    filas = []
    pares_tiempo = {a: [] for a, _ in ALGOS}
    puntos_pareto = {}  # (instancia, algoritmo) -> [(dist, riesgo, recargas), ...]

    inst_files = [DATA / f"inst_{n}.json" for n in [10, 15, 20, 25]]
    instancias = [(p, load_instance(str(p))) for p in inst_files]

    for inst_path, inst in instancias:
        # Para hipervolumen necesito un punto de referencia "peor".
        # Lo saco mirando todas las soluciones encontradas (aunque sea aproximado, vale).
        todos_2d = []

        for alg, params in ALGOS:
            tiempos, picos = [], []
            sols_para_metricas = None  # uso la 1ª repeticion para pareto (asi no tarda mas)

            for rep in range(5):  # <- aqui estan las 5 repeticiones del enunciado
                dt, peak, sols = medir_una_vez(inst, alg, params)
                tiempos.append(dt)
                picos.append(peak)
                if rep == 0:
                    sols_para_metricas = sols

            pts = []
            if sols_para_metricas:
                for s in sols_para_metricas:
                    pts.append((s.obj[0], s.obj[1], s.obj[2]))
                    todos_2d.append((s.obj[0], s.obj[1]))
            puntos_pareto[(inst.name, alg)] = pts

            filas.append({
                "instancia": inst.name,
                "N": inst.n,
                "algoritmo": alg,
                "tiempo_medio_s": mean(tiempos),
                "memoria_pico_media_kb": mean(picos) / 1024.0,
                "tam_pareto": len(pts),
                "hipervolumen": 0.0,
                "diversidad": 0.0,
            })
            pares_tiempo[alg].append((inst.n, mean(tiempos)))

        # Calculo hipervolumen y diversidad por algoritmo (en 2D: distancia vs riesgo)
        if todos_2d:
            max_d = max(p[0] for p in todos_2d)
            max_r = max(p[1] for p in todos_2d)
            ref = (max_d * 1.1, max_r * 1.1)

            for fila in filas:
                if fila["instancia"] != inst.name:
                    continue
                pts = puntos_pareto[(inst.name, fila["algoritmo"])]
                pts2d = [(p[0], p[1]) for p in pts]
                fila["hipervolumen"] = hypervolume_2d(pts2d, ref)
                fila["diversidad"] = diversity_nn(pts2d)

    # Guardar SOLO este CSV (lo pide el enunciado y lo que me pediste)
    csv_path = OUT / "metricas.csv"
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(filas[0].keys()))
        w.writeheader()
        w.writerows(filas)

    # Graficas (no son CSV, pero ayudan para la memoria)
    plot_time_vs_n(pares_tiempo, str(OUT / "tiempo_vs_n.png"))

    hv_25 = {}
    div_25 = {}
    pareto_25 = {}
    for alg, _ in ALGOS:
        fila = next(r for r in filas if r["instancia"] == "inst_25" and r["algoritmo"] == alg)
        hv_25[alg] = fila["hipervolumen"]
        div_25[alg] = fila["diversidad"]
        pareto_25[alg] = puntos_pareto[("inst_25", alg)]

    plot_bar(hv_25, "Hipervolumen (2D) en inst_25", str(OUT / "hipervolumen.png"))
    plot_bar(div_25, "Diversidad (NN) en inst_25", str(OUT / "diversidad.png"))
    plot_pareto(pareto_25, str(OUT / "pareto_inst_25.png"))

    print("OK, guardado:", csv_path)
    print("Y las graficas estan en:", OUT)

if __name__ == "__main__":
    main()
