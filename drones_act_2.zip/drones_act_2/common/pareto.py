# Cosas de pareto: dominancia, hipervolumen 2D y diversidad (vecino mas cercano).
# No es super academico pero vale para la practica.

"""
Utilidades para trabajar con optimización multiobjetivo (minimización):
- Dominancia de Pareto
- Mantener un conjunto no-dominado
- Hipervolumen 2D (aprox exacto en 2D)
- Métrica simple de diversidad (distancia media al vecino más cercano)
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple
import math

Obj = Tuple[float, float, int]  # (distancia, riesgo, recargas)

def dominates(a: Obj, b: Obj) -> bool:
    """a domina a b si a es <= en todo y < en al menos un objetivo."""
    return (a[0] <= b[0] and a[1] <= b[1] and a[2] <= b[2]) and (a != b)

def pareto_prune(solutions: List[Tuple[Obj, List[int]]]) -> List[Tuple[Obj, List[int]]]:
    """Elimina dominadas y duplicados exactos. Solución: (objetivos, ruta)."""
    out: List[Tuple[Obj, List[int]]] = []
    for obj, route in solutions:
        # duplicado exacto
        if any(obj == o2 and route == r2 for (o2, r2) in out):
            continue
        dominated = False
        for o2, _ in out:
            if dominates(o2, obj) or o2 == obj:  # si es igual en objetivos, mantenemos sólo una
                dominated = True if dominates(o2, obj) else False
        # Si alguna domina a esta, fuera.
        for o2, r2 in out:
            if dominates(o2, obj):
                dominated = True
                break
        if dominated:
            continue
        # Si esta domina a alguna, las quitamos.
        out = [(o2, r2) for (o2, r2) in out if not dominates(obj, o2)]
        out.append((obj, route))
    return out

def hypervolume_2d(points: List[Tuple[float, float]], ref: Tuple[float, float]) -> float:
    """
    Hipervolumen dominado en 2D para minimización (distancia, riesgo).
    Calcula el área de la unión de rectángulos desde cada punto hasta ref.
    Asume ref es peor (mayor) en ambos objetivos.
    """
    if not points:
        return 0.0
    pts = sorted(points, key=lambda p: (p[0], p[1]))
    hv = 0.0
    cur_y = ref[1]
    for x, y in pts:
        if y < cur_y:
            hv += max(0.0, ref[0] - x) * max(0.0, cur_y - y)
            cur_y = y
    return hv

def diversity_nn(points: List[Tuple[float, float]]) -> float:
    """Distancia media al vecino más cercano en 2D (si <2 puntos => 0)."""
    if len(points) < 2:
        return 0.0
    total = 0.0
    for i, p in enumerate(points):
        best = float("inf")
        for j, q in enumerate(points):
            if i == j: 
                continue
            d = math.hypot(p[0]-q[0], p[1]-q[1])
            best = min(best, d)
        total += best
    return total / len(points)