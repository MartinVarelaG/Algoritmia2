"""
Generación de gráficas con matplotlib:
- Tiempo vs N (escala log)
- Hipervolumen
- Diversidad

Se guardan como PNG en results/.
"""
from __future__ import annotations
from typing import Dict, List, Tuple
import math
import matplotlib.pyplot as plt

def plot_time_vs_n(time_by_alg: Dict[str, List[Tuple[int, float]]], out_path: str) -> None:
    plt.figure()
    for alg, pairs in time_by_alg.items():
        pairs = sorted(pairs, key=lambda x: x[0])
        ns = [n for n, _ in pairs]
        ts = [t for _, t in pairs]
        plt.plot(ns, ts, marker="o", label=alg)
    plt.yscale("log")
    plt.xlabel("N (destinos)")
    plt.ylabel("Tiempo medio (s) [escala log]")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=160)
    plt.close()

def plot_bar(metric_by_alg: Dict[str, float], ylabel: str, out_path: str) -> None:
    plt.figure()
    labels = list(metric_by_alg.keys())
    values = [metric_by_alg[k] for k in labels]
    plt.bar(labels, values)
    plt.ylabel(ylabel)
    plt.xticks(rotation=20, ha="right")
    plt.tight_layout()
    plt.savefig(out_path, dpi=160)
    plt.close()

def plot_pareto(points_by_alg: Dict[str, List[Tuple[float, float, int]]], out_path: str) -> None:
    plt.figure()
    for alg, pts in points_by_alg.items():
        xs = [p[0] for p in pts]
        ys = [p[1] for p in pts]
        plt.scatter(xs, ys, label=alg, s=20)
    plt.xlabel("Distancia total")
    plt.ylabel("Riesgo total")
    plt.legend()
    plt.tight_layout()
    plt.savefig(out_path, dpi=160)
    plt.close()
