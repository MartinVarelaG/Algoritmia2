# Funciones de geometria. Aqui miro si un segmento corta un poligono (no-fly) y calculos basicos.

"""
Geometría 2D básica para:
- Intersección de segmentos
- Punto dentro de polígono
- Distancias (punto-segmento, punto-polígono)

Se usa para comprobar que una arista (trayectoria recta del dron) NO cruza polígonos no-fly,
y para aproximar el "riesgo" en función de la cercanía a dichas zonas.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple
import math

EPS = 1e-9

Point = Tuple[float, float]

def _orient(a: Point, b: Point, c: Point) -> float:
    # Producto cruzado (b-a) x (c-a)
    return (b[0]-a[0])*(c[1]-a[1]) - (b[1]-a[1])*(c[0]-a[0])

def _on_segment(a: Point, b: Point, c: Point) -> bool:
    # c colineal con a-b y dentro de la caja
    return (min(a[0], b[0]) - EPS <= c[0] <= max(a[0], b[0]) + EPS and
            min(a[1], b[1]) - EPS <= c[1] <= max(a[1], b[1]) + EPS)

def segments_intersect(p1: Point, p2: Point, q1: Point, q2: Point) -> bool:
    """Intersección de segmentos p1-p2 con q1-q2 (incluye colineales)."""
    o1 = _orient(p1, p2, q1)
    o2 = _orient(p1, p2, q2)
    o3 = _orient(q1, q2, p1)
    o4 = _orient(q1, q2, p2)

    # Caso general
    if (o1 > EPS and o2 < -EPS or o1 < -EPS and o2 > EPS) and (o3 > EPS and o4 < -EPS or o3 < -EPS and o4 > EPS):
        return True

    # Casos colineales
    if abs(o1) <= EPS and _on_segment(p1, p2, q1): return True
    if abs(o2) <= EPS and _on_segment(p1, p2, q2): return True
    if abs(o3) <= EPS and _on_segment(q1, q2, p1): return True
    if abs(o4) <= EPS and _on_segment(q1, q2, p2): return True
    return False

def point_in_polygon(p: Point, poly: List[Point]) -> bool:
    """Ray casting. True si p está dentro o sobre el borde."""
    x, y = p
    inside = False
    n = len(poly)
    for i in range(n):
        x1, y1 = poly[i]
        x2, y2 = poly[(i+1) % n]
        # Check punto en borde
        if abs(_orient((x1,y1),(x2,y2),(x,y))) <= EPS and _on_segment((x1,y1),(x2,y2),(x,y)):
            return True
        # Ray casting
        intersects = ((y1 > y) != (y2 > y)) and (x < (x2-x1) * (y-y1) / ((y2-y1) + EPS) + x1)
        if intersects:
            inside = not inside
    return inside

def dist(a: Point, b: Point) -> float:
    return math.hypot(a[0]-b[0], a[1]-b[1])

def point_segment_distance(p: Point, a: Point, b: Point) -> float:
    """Distancia mínima del punto p al segmento a-b."""
    ax, ay = a
    bx, by = b
    px, py = p
    abx, aby = bx-ax, by-ay
    apx, apy = px-ax, py-ay
    ab2 = abx*abx + aby*aby
    if ab2 <= EPS:
        return dist(p, a)
    t = (apx*abx + apy*aby) / ab2
    t = max(0.0, min(1.0, t))
    proj = (ax + t*abx, ay + t*aby)
    return dist(p, proj)

def point_polygon_distance(p: Point, poly: List[Point]) -> float:
    """Distancia aproximada del punto p al borde del polígono (0 si dentro)."""
    if point_in_polygon(p, poly):
        return 0.0
    m = float("inf")
    for i in range(len(poly)):
        a = poly[i]
        b = poly[(i+1) % len(poly)]
        m = min(m, point_segment_distance(p, a, b))
    return m

def segment_intersects_polygon(a: Point, b: Point, poly: List[Point]) -> bool:
    """True si el segmento a-b cruza o toca el polígono."""
    # Si cualquiera de los extremos está dentro, lo consideramos intersección (no-fly).
    if point_in_polygon(a, poly) or point_in_polygon(b, poly):
        return True
    for i in range(len(poly)):
        p = poly[i]
        q = poly[(i+1) % len(poly)]
        if segments_intersect(a, b, p, q):
            return True
    return False

def segment_min_distance_to_polygon(a: Point, b: Point, poly: List[Point], samples: int = 7) -> float:
    """
    Distancia mínima aproximada del segmento a-b al polígono:
    - 0 si intersecta
    - sino, muestreamos puntos en el segmento y calculamos dist punto-polígono.
    """
    if segment_intersects_polygon(a, b, poly):
        return 0.0
    best = float("inf")
    for i in range(samples):
        t = i / (samples - 1)
        p = (a[0] + t*(b[0]-a[0]), a[1] + t*(b[1]-a[1]))
        best = min(best, point_polygon_distance(p, poly))
    return best