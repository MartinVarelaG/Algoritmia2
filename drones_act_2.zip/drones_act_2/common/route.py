"""
Evaluación de rutas (permutaciones) con:
- Objetivos: (distancia total, riesgo total, #recargas)
- Restricciones:
  - circuito Hamiltoniano: hub -> ... -> hub
  - no cruza no-fly (feasible[i][j])
  - factible por batería con recargas sólo en estaciones/hub

Nota: Para un orden dado, calculamos el número MÍNIMO de recargas
asumiendo que el dron recarga sólo cuando lo necesita (política greedy).
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple, Optional

from .instance import Instance

Obj = Tuple[float, float, int]

@dataclass(frozen=True)
class EvalResult:
    ok: bool
    obj: Optional[Obj] = None
    route: Optional[List[int]] = None

def evaluate_route(inst: Instance, order: List[int]) -> EvalResult:
    """
    order: lista de nodos VISITADOS en orden, incluyendo hub al inicio,
           y SIN repetir nodos intermedios.
           Ejemplo: [0, 5, 2, 1, 3, 0]
    """
    if len(order) < 2:
        return EvalResult(False)
    if order[0] != inst.hub or order[-1] != inst.hub:
        return EvalResult(False)
    # Comprobar Hamiltoniano: todos una vez excepto hub.
    visited = order[1:-1]
    if len(set(visited)) != len(visited):
        return EvalResult(False)
    if inst.hub in visited:
        return EvalResult(False)
    if len(visited) != inst.n - 1:
        return EvalResult(False)

    dist_total = 0.0
    risk_total = 0.0
    recharges = 0
    cap = inst.battery_capacity
    battery = cap  # arrancamos con batería llena en el hub

    for a, b in zip(order[:-1], order[1:]):
        if not inst.feasible[a][b]:
            return EvalResult(False)
        cons = inst.w_cons[a][b]
        if cons > cap:
            return EvalResult(False)  # imposible incluso recargando
        # Si no llega, necesita recarga ANTES de salir.
        if battery + 1e-9 < cons:
            if a in inst.recharge_stations:
                recharges += 1
                battery = cap
            else:
                return EvalResult(False)
        battery -= cons
        dist_total += inst.w_dist[a][b]
        risk_total += inst.w_risk[a][b]

    return EvalResult(True, (dist_total, risk_total, recharges), order)
