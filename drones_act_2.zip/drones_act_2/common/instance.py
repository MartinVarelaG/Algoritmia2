# Cargar la instancia desde JSON. Aqui vienen los nodos, poligonos no-fly y estaciones de recarga.

"""
Carga de instancias JSON y precomputación de:
- Matriz de factibilidad de aristas (no-fly)
- Matrices de pesos (distancia, riesgo, consumo)

Formato JSON esperado (ver datasets/*.json):
{
  "name": "...",
  "hub": 0,
  "nodes": [{"id":0,"x":..,"y":..,"type":"hub"|"delivery"|"station"}, ...],
  "recharge_stations": [0, 3, 7, ...],
  "battery_capacity": 80.0,
  "polygons": [{"id":0,"points":[[x,y],...]}, ...],
  "risk_beta": 3.0
}
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple, Dict
import json
import math

from .geometry import dist, segment_intersects_polygon, segment_min_distance_to_polygon

@dataclass(frozen=True)
class Node:
    id: int
    x: float
    y: float
    type: str  # hub|delivery|station

    @property
    def p(self) -> Tuple[float, float]:
        return (self.x, self.y)

@dataclass
class Instance:
    name: str
    hub: int
    nodes: List[Node]
    recharge_stations: set
    battery_capacity: float
    polygons: List[List[Tuple[float, float]]]
    risk_beta: float = 3.0

    # precomputadas:
    feasible: List[List[bool]] = None
    w_dist: List[List[float]] = None
    w_risk: List[List[float]] = None
    w_cons: List[List[float]] = None

    @property
    def n(self) -> int:
        return len(self.nodes)

def load_instance(path: str) -> Instance:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    nodes = [Node(**nd) for nd in data["nodes"]]
    polys = []
    for poly in data.get("polygons", []):
        pts = [(float(x), float(y)) for x, y in poly["points"]]
        polys.append(pts)
    inst = Instance(
        name=data.get("name", path),
        hub=int(data["hub"]),
        nodes=nodes,
        recharge_stations=set(map(int, data["recharge_stations"])),
        battery_capacity=float(data["battery_capacity"]),
        polygons=polys,
        risk_beta=float(data.get("risk_beta", 3.0)),
    )
    precompute(inst)
    return inst

def precompute(inst: Instance) -> None:
    n = inst.n
    inst.feasible = [[True]*n for _ in range(n)]
    inst.w_dist = [[0.0]*n for _ in range(n)]
    inst.w_risk = [[0.0]*n for _ in range(n)]
    inst.w_cons = [[0.0]*n for _ in range(n)]
    for i in range(n):
        for j in range(n):
            if i == j:
                inst.feasible[i][j] = False
                continue
            a = inst.nodes[i].p
            b = inst.nodes[j].p
            d = dist(a, b)
            feasible = True
            dmin = float("inf")
            for poly in inst.polygons:
                if segment_intersects_polygon(a, b, poly):
                    feasible = False
                    dmin = 0.0
                    break
                dmin = min(dmin, segment_min_distance_to_polygon(a, b, poly))
            if dmin == float("inf"):  # sin polígonos
                dmin = 9999.0
            # Riesgo: más alto si el segmento pasa cerca de zonas no-fly
            beta = inst.risk_beta
            risk = d * (1.0 + (beta / (dmin + 1.0)))
            inst.feasible[i][j] = feasible
            inst.w_dist[i][j] = d
            inst.w_risk[i][j] = risk
            inst.w_cons[i][j] = d  # consumo proporcional a distancia (simplificación)