from __future__ import annotations
import argparse, json
from common.instance import load_instance
from .solver import solve

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("instance", help="Ruta al .json de instancia")
    ap.add_argument("--time_limit", type=float, default=3.0)
    ap.add_argument("--out", default="", help="Si se indica, guarda soluciones en JSON")
    args = ap.parse_args()

    inst = load_instance(args.instance)
    sols = solve(inst, time_limit=args.time_limit)

    if not sols:
        print("No se encontró ninguna solución factible.")
        return

    print(f"Instancia: {inst.name}  N={inst.n}")
    for s in sorted(sols, key=lambda x: (x.obj[2], x.obj[0], x.obj[1]))[:20]:
        print(f"obj={s.obj}  route={s.route}")

    if args.out:
        payload = [{"obj": list(s.obj), "route": s.route} for s in sols]
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)

if __name__ == "__main__":
    main()
