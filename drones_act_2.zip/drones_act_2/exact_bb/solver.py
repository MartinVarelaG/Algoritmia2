# Solver 'exact' (branch and bound). Ojo: no es 100% exacto pq tengo un time_limit.
# La idea es ir probando permutaciones y podar cuando ya pinta mal.

"""
Backtracking / Branch-and-Bound multiobjetivo (aprox. exacto para N pequeños).
- Genera permutaciones del Hamiltoniano (hub fijo) y podas con cotas inferiores
  de distancia y riesgo.
- Mantiene un conjunto no-dominado (Pareto) con (dist, riesgo, recargas).

Nota práctica:
Para N=15..25 el espacio es enorme; por eso se permite un time_limit.
La idea es enseñar la técnica, no "ganar" un benchmark industrial.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple, Optional
import time

from common.instance import Instance
from common.route import evaluate_route
from common.pareto import pareto_prune, dominates

Obj = Tuple[float, float, int]

@dataclass
class BBSolution:
    obj: Obj
    route: List[int]

def solve(inst: Instance, time_limit: float = 3.0, seed_order: str = "nn") -> List[BBSolution]:
    start_t = time.perf_counter()

    n = inst.n
    hub = inst.hub
    nodes = list(range(n))
    others = [i for i in nodes if i != hub]

    # Precompute min outgoing weights for lower bounds (consider only feasible edges).
    min_out_d = [float("inf")] * n
    min_out_r = [float("inf")] * n
    for i in range(n):
        for j in range(n):
            if i == j or not inst.feasible[i][j]:
                continue
            min_out_d[i] = min(min_out_d[i], inst.w_dist[i][j])
            min_out_r[i] = min(min_out_r[i], inst.w_risk[i][j])
        if min_out_d[i] == float("inf"):
            # Nodo aislado => instancia imposible
            return []
        if min_out_r[i] == float("inf"):
            return []

    # Orden inicial heurístico para encontrar soluciones pronto.
    def nn_order():
        unv = set(others)
        cur = hub
        route = [hub]
        while unv:
            cand = []
            for j in unv:
                if inst.feasible[cur][j]:
                    cand.append((inst.w_dist[cur][j], j))
            if not cand:
                break
            _, nxt = min(cand)
            route.append(nxt)
            unv.remove(nxt)
            cur = nxt
        route.append(hub)
        return route

    initial = []
    if seed_order == "nn":
        r = nn_order()
        ev = evaluate_route(inst, r)
        if ev.ok:
            initial.append((ev.obj, ev.route))

    pareto = pareto_prune(initial)  # list[(obj, route)]

    # Dominance pruning using optimistic lower bounds (d,r,0).
    def prune_by_lb(lb_d: float, lb_r: float) -> bool:
        # si existe solución en pareto que domina incluso a la mejor esperanza (lb, 0 recargas)
        for obj, _ in pareto:
            if obj[0] <= lb_d and obj[1] <= lb_r and obj[2] <= 0:
                return True
        return False

    # Recursión
    best_found = 0

    # Bitset remaining
    # Map others indices to bit positions
    idx_map = {node:i for i, node in enumerate(others)}
    full_mask = 0
    for node in others:
        full_mask |= (1 << idx_map[node])

    def iter_nodes(mask: int):
        # iterate node ids in mask (in a heuristic order: nearest distance from current set later)
        # We'll just yield in natural order for simplicity.
        while mask:
            lsb = mask & -mask
            pos = (lsb.bit_length() - 1)
            mask ^= lsb
            yield others[pos]

    # Precompute sums of min_out for subsets? too heavy. We'll use simple LB = cur + sum(min_out for remaining) + min_out(last)
    def sum_min_out(mask: int):
        sd = 0.0
        sr = 0.0
        m = mask
        while m:
            lsb = m & -m
            pos = (lsb.bit_length() - 1)
            node = others[pos]
            sd += min_out_d[node]
            sr += min_out_r[node]
            m ^= lsb
        return sd, sr

    def dfs(path: List[int], mask: int, cur_d: float, cur_r: float):
        nonlocal pareto, best_found
        if time.perf_counter() - start_t > time_limit:
            return

        last = path[-1]

        if mask == 0:
            # close cycle
            if not inst.feasible[last][hub]:
                return
            d = cur_d + inst.w_dist[last][hub]
            r = cur_r + inst.w_risk[last][hub]
            order = path + [hub]
            ev = evaluate_route(inst, order)
            if not ev.ok:
                return
            pareto = pareto_prune(pareto + [(ev.obj, ev.route)])
            best_found += 1
            return

        # Lower bound
        sd, sr = sum_min_out(mask)
        lb_d = cur_d + sd + min_out_d[last]
        lb_r = cur_r + sr + min_out_r[last]
        if prune_by_lb(lb_d, lb_r):
            return

        # Branching: prefer closer nodes first to find good solutions early
        candidates = []
        for node in iter_nodes(mask):
            if inst.feasible[last][node]:
                candidates.append((inst.w_dist[last][node], node))
        candidates.sort(key=lambda x: x[0])

        for _, node in candidates:
            if time.perf_counter() - start_t > time_limit:
                return
            bit = 1 << idx_map[node]
            new_mask = mask & ~bit
            dfs(path + [node], new_mask, cur_d + inst.w_dist[last][node], cur_r + inst.w_risk[last][node])

    dfs([hub], full_mask, 0.0, 0.0)

    return [BBSolution(obj=o, route=r) for o, r in pareto]