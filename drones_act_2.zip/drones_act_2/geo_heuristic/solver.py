# Solver heuristico geometrico. Hace greedy y luego un 2-opt para apañar la ruta.
# Es el mas rapido casi siempre.

"""
Heurística geométrica:
- Usa tests de intersección de segmentos para filtrar aristas factibles.
- Construye una ruta greedy (tipo nearest neighbor) con función de score multiobjetivo
  (mezcla distancia/riesgo).
- Aplica mejora local simple (2-opt) manteniendo factibilidad.

Devuelve conjunto Pareto aproximado.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple
import random

from common.instance import Instance
from common.route import evaluate_route
from common.pareto import pareto_prune

Obj = Tuple[float, float, int]

@dataclass
class GeoSolution:
    obj: Obj
    route: List[int]

def _score(inst: Instance, i: int, j: int, alpha: float, dmin: float, dmax: float, rmin: float, rmax: float) -> float:
    d = inst.w_dist[i][j]
    r = inst.w_risk[i][j]
    dn = (d - dmin) / (dmax - dmin + 1e-9)
    rn = (r - rmin) / (rmax - rmin + 1e-9)
    return alpha * dn + (1 - alpha) * rn

def _edge_stats(inst: Instance):
    ds, rs = [], []
    for i in range(inst.n):
        for j in range(inst.n):
            if i != j and inst.feasible[i][j]:
                ds.append(inst.w_dist[i][j])
                rs.append(inst.w_risk[i][j])
    return min(ds), max(ds), min(rs), max(rs)

def build_greedy(inst: Instance, alpha: float, rng: random.Random) -> List[int] | None:
    hub = inst.hub
    unv = set(range(inst.n))
    unv.remove(hub)

    dmin, dmax, rmin, rmax = _edge_stats(inst)

    route = [hub]
    cur = hub
    while unv:
        candidates = []
        for j in unv:
            if inst.feasible[cur][j]:
                candidates.append(j)
        if not candidates:
            return None

        # Score, con pequeña aleatoriedad para variar soluciones
        scored = []
        for j in candidates:
            s = _score(inst, cur, j, alpha, dmin, dmax, rmin, rmax)
            s *= (1.0 + 0.05 * rng.random())
            scored.append((s, j))
        scored.sort(key=lambda x: x[0])
        nxt = scored[0][1]
        route.append(nxt)
        unv.remove(nxt)
        cur = nxt

    route.append(hub)
    ev = evaluate_route(inst, route)
    return route if ev.ok else None

def two_opt(inst: Instance, route: List[int], max_iter: int = 200) -> List[int]:
    best = route
    best_ev = evaluate_route(inst, best)
    if not best_ev.ok:
        return route

    improved = True
    it = 0
    while improved and it < max_iter:
        improved = False
        it += 1
        n = len(best)
        # i y k evitan tocar el hub inicial/final
        for i in range(1, n-3):
            for k in range(i+1, n-2):
                # 2-opt: invertir segmento [i:k]
                new_route = best[:i] + list(reversed(best[i:k+1])) + best[k+1:]
                ev = evaluate_route(inst, new_route)
                if not ev.ok:
                    continue
                # Mejoras por distancia + riesgo (no tocamos recargas aquí)
                if ev.obj[0] + ev.obj[1] < best_ev.obj[0] + best_ev.obj[1]:
                    best = new_route
                    best_ev = ev
                    improved = True
        # si mejora, seguimos
    return best

def solve(inst: Instance, seeds: int = 8) -> List[GeoSolution]:
    rng = random.Random(42)
    pareto = []
    alphas = [0.0, 0.25, 0.5, 0.75, 1.0]
    for a in alphas:
        for _ in range(seeds):
            r = build_greedy(inst, a, rng)
            if not r:
                continue
            r2 = two_opt(inst, r)
            ev = evaluate_route(inst, r2)
            if ev.ok:
                pareto = pareto_prune(pareto + [(ev.obj, ev.route)])
    return [GeoSolution(obj=o, route=r) for o, r in pareto]