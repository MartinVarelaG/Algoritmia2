from __future__ import annotations
import argparse, json
from common.instance import load_instance
from .solver import solve

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("instance")
    ap.add_argument("--out", default="")
    ap.add_argument("--seeds", type=int, default=8)
    args = ap.parse_args()

    inst = load_instance(args.instance)
    sols = solve(inst, seeds=args.seeds)

    if not sols:
        print("No se encontró ninguna solución factible.")
        return

    print(f"Instancia: {inst.name}  N={inst.n}")
    for s in sorted(sols, key=lambda x: (x.obj[2], x.obj[0], x.obj[1]))[:20]:
        print(f"obj={s.obj}  route={s.route}")

    if args.out:
        payload = [{"obj": list(s.obj), "route": s.route} for s in sols]
        with open(args.out, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)

if __name__ == "__main__":
    main()
